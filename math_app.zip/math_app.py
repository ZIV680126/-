
# math_app.py
import streamlit as st
import random
from PIL import Image

# --- פונקציות עזר ---
def get_random_question(topic):
    if topic == "לוח הכפל":
        a, b = random.randint(1, 10), random.randint(1, 10)
        return f"{a} × {b} = ?", a * b
    elif topic == "סדר פעולות":
        a, b, c = random.randint(1, 10), random.randint(1, 10), random.randint(1, 10)
        return f"{a} + {b} × {c} = ?", a + b * c
    elif topic == "חילוק":
        b = random.randint(1, 10)
        c = random.randint(1, 10)
        a = b * c
        return f"{a} ÷ {b} = ?", c
    elif topic == "בעיות מילוליות":
        a, b = random.randint(1, 10), random.randint(1, 10)
        return f"אם יש לך {a} תפוחים ואתה קונה עוד {b}, כמה יהיו לך?", a + b
    elif topic == "גיאומטריה":
        a = random.randint(1, 10)
        return f"היקף ריבוע שאורך צלעו {a} = ?", 4 * a
    return "", 0

# --- משתנים של מצב ---
if "profile" not in st.session_state:
    st.session_state.profile = {
        "name": "תלמיד",
        "points": 0,
        "coins": 0,
        "level": 1,
        "avatar": None,
        "lang": "עברית",
        "sound": True,
        "stars": 0,
        "tasks_done": [],
    }

profile = st.session_state.profile

# --- תפריט ---
st.sidebar.title("📚 תפריט")
page = st.sidebar.radio("בחר עמוד:", ["🏠 בית", "🎮 משחקים", "🗝️ חדר בריחה", "👤 פרופיל", "⚙️ הגדרות"])

# --- דף בית ---
if page == "🏠 בית":
    st.title("ברוך הבא לאפליקציית מתמטיקה 🧮")
    st.write("התחל לתרגל ולצבור נקודות!")

# --- משחקים ---
elif page == "🎮 משחקים":
    st.title("🎮 נושאי תרגול")
    topic = st.selectbox("בחר נושא:", ["לוח הכפל", "סדר פעולות", "חילוק", "גיאומטריה", "בעיות מילוליות"])
    question, answer = get_random_question(topic)
    st.write(f"**שאלה:** {question}")
    user_answer = st.number_input("הזן תשובה:", step=1)
    if st.button("בדוק"):
        if user_answer == answer:
            st.success("נכון מאוד! 🥳")
            profile["points"] += 10
            profile["coins"] += 1
            if profile["points"] >= profile["level"] * 250:
                profile["level"] += 1
                st.balloons()
        else:
            st.error("נסה שוב!")

# --- חדר בריחה ---
elif page == "🗝️ חדר בריחה":
    st.title("🗝️ חדר בריחה מתמטי")
    st.write("פתור חידות כדי לברוח!")
    # שלב פשוט לדוגמה
    riddle = "אני מספר זוגי בין 10 ל-20, מחלק ב-4 וב-2. מי אני?"
    st.write(riddle)
    escape_answer = st.number_input("תשובתך:", step=1, key="escape")
    if st.button("שלח"):
        if escape_answer == 12 or escape_answer == 16:
            st.success("כל הכבוד! פתרת שלב בחדר הבריחה!")
            profile["points"] += 20
        else:
            st.error("נסה שוב!")

# --- פרופיל ---
elif page == "👤 פרופיל":
    st.title("👤 פרופיל שלי")
    profile["name"] = st.text_input("שם:", value=profile["name"])
    st.write(f"נקודות: {profile['points']}")
    st.write(f"מטבעות: {profile['coins']}")
    st.write(f"רמה: {profile['level']}")
    uploaded = st.file_uploader("העלה תמונת פרופיל:", type=["jpg", "png"])
    if uploaded:
        img = Image.open(uploaded)
        profile["avatar"] = img
    if profile["avatar"]:
        st.image(profile["avatar"], width=150)
    st.write(f"⭐ דירג את האפליקציה:")
    profile["stars"] = st.slider("דירוג:", 1, 5, value=profile["stars"])

# --- הגדרות ---
elif page == "⚙️ הגדרות":
    st.title("⚙️ הגדרות")
    lang = st.selectbox("בחר שפה:", ["עברית", "אנגלית"])
    profile["lang"] = lang
    profile["sound"] = st.checkbox("השמע צלילים", value=profile["sound"])
    st.success("הגדרות נשמרו!")

# --- משימות יומיות ---
st.sidebar.markdown("---")
st.sidebar.subheader("📋 משימות")
daily = [
    "מרתון יום אחד: 30 תשובות נכונות",
    "הגיימר הנצחי: סיים 150 מבחנים",
    "הפותר הגאון: פתר 700 תרגילים",
    "הינשוף הנצחי: פתר 150 תרגילים לפני 9 בבוקר",
]

for task in daily:
    st.sidebar.write(f"✅ {task}")
